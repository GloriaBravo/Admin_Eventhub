import React from "react";
import "../styles/LoadingModal.css";

const LoadingModal = ({ show, text = "Cargando..." }) => {
  if (!show) return null;

  return (
    <div className="modal-overlay">
      <div className="modal-loader">
        <div className="spinner"></div>
        <p>{text}</p>
      </div>
    </div>
  );
};

export default LoadingModal;
